import { DEFAULT_LAYOUT } from '../base';
import { AppRouteRecordRaw } from '../types';

const ABOUT: AppRouteRecordRaw = {
    path: '/about',
    name: 'about',
    component: DEFAULT_LAYOUT,
    meta: {
        locale: 'menu.dashboard',
        requiresAuth: true,
        icon: 'icon-dashboard',
        order: 0,
    },
    children: [
        {
            path: 'about',
            name: 'about',
            component: () => import('@/views/about/index.vue'),
            meta: {
                locale: 'menu.dashboard.workplace',
                requiresAuth: true,
                roles: ['*'],
            },

        }
    ],
};
export default ABOUT;
