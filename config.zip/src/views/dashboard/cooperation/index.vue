<template>
  <div>2222222222222</div>
</template>

<script lang="ts" setup>
import { ref } from "vue";
</script>

<style lang="ts"></style>
