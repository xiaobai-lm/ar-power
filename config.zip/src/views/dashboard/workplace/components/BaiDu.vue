<template>
  <div>
    <iframe src="https://www.hao123.com/" style="width: 100%; height: 88vh"></iframe>
  </div>
</template>

<script lang="ts" setup></script>

<style lang="less"></style>
