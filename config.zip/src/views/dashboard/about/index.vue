<template>
  <div class="container">
    <div>about</div>
  </div>
</template>

<script lang="ts" setup></script>

<style lang="less" scoped></style>
